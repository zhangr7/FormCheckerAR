//
//  Bones.swift
//  FormCheckerAR


import Foundation

enum Bones: CaseIterable {
    case leftShoulderToLeftArm
    case leftArmToLeftForearm
}
