//
//  SkeletonJoint.swift
//  FormCheckerAR

import Foundation

struct SkeletonJoint {
    let name: String
    var position: SIMD3<Float>
}
